from flask import Flask, render_template,request, redirect, url_for
import pandas as pd
from sklearn.feature_extraction.text import TfidfVectorizer
from sklearn.metrics.pairwise import cosine_similarity

app = Flask(__name__,static_url_path='/static')

# Load the dataset
data = pd.read_csv("DMart.csv")

# Drop rows with missing values
custom_data = 'Not Available'

# Fill null values in the entire DataFrame with the custom data
data.fillna(custom_data, inplace=True)
# data.dropna(inplace=True)
cart_items = []
# Initialize TF-IDF Vectorizer
tfidf_vectorizer = TfidfVectorizer(stop_words='english')

# Fit and transform the breadcrumbs feature
tfidf_matrix = tfidf_vectorizer.fit_transform(data['BreadCrumbs'])

# Compute cosine similarity matrix
cosine_sim = cosine_similarity(tfidf_matrix, tfidf_matrix)

# Function to recommend similar products based on breadcrumbs
def recommend_products(product_name, cosine_sim=cosine_sim):
    idx = data[data['Name'] == product_name].index
    if len(idx) == 0:
        return []  # Product not found
    idx = idx[0]
    sim_scores = list(enumerate(cosine_sim[idx]))
    sim_scores = sorted(sim_scores, key=lambda x: x[1], reverse=True)
    sim_scores = sim_scores[1:11]
    product_indices = [i[0] for i in sim_scores]
    recommended_products=data['Name'].iloc[product_indices].unique()
    recommended_products = [p for p in recommended_products if p != product_name]
    return recommended_products

# Function to group products by category
def group_products_by_category():
    grouped_by_category = data.groupby('Category')['Name'].apply(list)
    return grouped_by_category

@app.route('/')
def index():
    # Get the list of categories with products
    categories = data[data['Category'] != 'Not Available']['Category'].unique()
    return render_template('index.html', categories=categories)

@app.route('/category/<category_name>')
def category(category_name):
    grouped_by_category = data.groupby('Category')['Name'].apply(list)
    products = grouped_by_category.get(category_name, [])
    return render_template('category.html', category_name=category_name, products=products)

@app.route('/product/<product_name>')
def product(product_name):
    product_row = data[data['Name'] == product_name]
    if product_row.empty:
        return "Product not found.", 404
    product_data = product_row.to_dict(orient='records')[0]
    recommended = recommend_products(product_name)
    return render_template('product.html', product_name=product_name, product_data=product_data,recommended=recommended,cart_items=cart_items)

@app.route('/cart')
def cart():
    return render_template('cart.html', cart_items=cart_items)

@app.route('/add_or_remove_from_cart', methods=['POST'])
def add_or_remove_from_cart():
    if request.method == 'POST':
        product_name = request.form['product_name']
        action = request.form['action']
        if action == 'add':
            if product_name not in cart_items:
                cart_items.append(product_name)
        elif action == 'remove':
            if product_name in cart_items:
                cart_items.remove(product_name)
        # Redirect back to the product page
        return redirect(url_for('product', product_name=product_name))
    

@app.route('/recommendations/<product_name>')
def recommendations(product_name):
    # Get recommendations for the selected product
    recommended_products = recommend_products(product_name)
    return render_template('recommendations.html', product_name=product_name, recommended_products=recommended_products)

if __name__ == '__main__':
    app.run(debug=True)
